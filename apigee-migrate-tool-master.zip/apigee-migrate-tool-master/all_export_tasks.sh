#!/bin/bash
grunt exportDevs -v
grunt exportProducts -v
grunt exportApps -v
grunt exportProxies -v
grunt exportSharedFlows -v
grunt exportProxyKVM -v
grunt exportEnvKVM -v
grunt exportOrgKVM -v
grunt exportFlowHooks -v
exportTargetServers -v
grunt exportReports -v
