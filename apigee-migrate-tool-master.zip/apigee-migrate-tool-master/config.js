module.exports = {

	from: {
		version: '19.04',
		url: 'https://api.enterprise.apigee.com',
		userid: 'admin@google.com',
		passwd: 'SuperSecret123',
		org: 'org1',
		env: 'test'
	},
	to: {
		version: '19.04',
		url: 'https://api.enterprise.apigee.com',
		userid: 'admin@google.com',
		passwd: 'SuperSecret123!9',
		org: 'org2',
		env: 'test'
	}
} ;
